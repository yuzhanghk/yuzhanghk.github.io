function [prediction,model]=MTWGP(traindata,trainlabel,testdata)
%traindata: a cell array. Each cell in the array contains a training data 
%           matrix, each row of whom represents a training data point, for the corresponding task
%trainlabel: a cell array. Each cell in the array contains a row vector, 
%            each element of whom represents a label, for the corresponding task
%testdata: a data matrix with each row as one test data point
%prediction: the prediction on the test data in the format of a row vector
%model: a struct variable containing the learned model parameters
    m=length(traindata);
    [traindata,trainlabel,train_task_index]=PreprocessMTData(traindata,trainlabel);
    n=size(traindata,1);
    kernel_option=1;
    kernel_parameter_dim=2;
    transform_parameter_dim=4;
    distMatrix=CalPairwiseDis(traindata); 
    insIndex=cell(1,m);
    for i=1:m
        insIndex{i}=sort(find(train_task_index==i));
    end
    meanDis=sum(distMatrix(:))/(n*(n-1));
    sigma=0.3*ones(1,m);
    theta=[1 meanDis];
    transform_par=[1,1,0.5,0];
    hyperprior=[log(0.3) 0.05];
    max_iteration=20;
    for i=1:max_iteration
        sigma=exp(minimizor(log(sigma)', @obj1, -5,traindata,trainlabel,1:m,sigma,theta,transform_par,hyperprior,train_task_index,distMatrix,insIndex,kernel_option)');
        optimal_value=minimizor([log(theta),log(transform_par(1:3)),transform_par(4),hyperprior(1),log(hyperprior(2))]', @obj2, -10,traindata,trainlabel,sigma,train_task_index,distMatrix,m,kernel_option,kernel_parameter_dim,transform_parameter_dim);
        theta=exp(optimal_value(1:kernel_parameter_dim))';
        transform_par=[exp(optimal_value((kernel_parameter_dim+1):(kernel_parameter_dim+transform_parameter_dim-1)))',optimal_value(kernel_parameter_dim+transform_parameter_dim)];
        hyperprior=[optimal_value(kernel_parameter_dim+transform_parameter_dim+1),exp(optimal_value(end))];
    end
    model.sigma=sigma;
    model.theta=theta;
    model.transform_par=transform_par;
    model.hyperprior=hyperprior;
    z=TransformFun(trainlabel,transform_par);
    train_Km=CalculateMTGPKernelMatrix2(traindata,distMatrix,theta,kernel_option);
    inv_Km=pinv(diag(sigma(train_task_index).^2)+train_Km);
    clear train_Km;
    test_Km=CalculateMTGPKernelMatrix(testdata,traindata,theta,kernel_option);
    prediction=(test_Km*inv_Km*z')';
    prediction=InvTransformFun(prediction,transform_par);
    clear inv_Km test_Km z optimal_value traindata trainlabel testdata distMatrix train_task_index insIndex sigma theta transform_par hyperprior;
    
function [f,g]=obj1(x,traindata,trainlabel,index,sigma0,theta0,par0,hyperprior0,train_task_index,distMatrix,insIndex,kernel_option)
    new_sigma=exp(x)';
    sigma0(index)=new_sigma;
    mu0=hyperprior0(1);
    rho0=exp(hyperprior0(2));
    n=size(traindata,1);
    original_Km=CalculateMTGPKernelMatrix2(traindata,distMatrix,theta0,kernel_option);
    Km=diag(sigma0(train_task_index).^2)+original_Km;
    clear original_Km;
    if any(isinf(Km(:))+isnan(Km(:)))
        f=inf;
        g=ones(size(x))*inf;
        return;
    end
    L = chol(Km)';
    clear Km;
    inv_Km=L'\(L\eye(n));
    z=TransformFun(trainlabel,par0);
    f=z*inv_Km*z'/2+sum(log(diag(L)))+sum(log(sigma0(index)))+(log(sigma0(index))-mu0)*(log(sigma0(index))-mu0)'/(2*rho0^2);
    clear L;
    tmp=inv_Km*z';
    tmp=inv_Km-tmp*tmp';
    clear Km inv_Km;
    temp=diag(tmp);
    clear tmp;
    g=zeros(size(x));
    for i=1:length(index)
        g(i)=sigma0(index(i))^2*sum(temp(insIndex{index(i)}))+1+(log(sigma0(index(i)))-mu0)/rho0^2;
    end
    clear temp traindata trainlabel train_task_index distMatrix insIndex;
    
function [f,g]=obj2(x,traindata,trainlabel,sigma0,train_task_index,distMatrix,m,kernel_option,kernel_parameter_dim,transform_parameter_dim)
    theta0=exp(x(1:kernel_parameter_dim));
    par0=[exp(x((kernel_parameter_dim+1):(kernel_parameter_dim+transform_parameter_dim-1)))',x(kernel_parameter_dim+transform_parameter_dim)];
    mu0=x(kernel_parameter_dim+transform_parameter_dim+1);
    rho0=exp(x(end));
    n=size(traindata,1);
    original_Km=CalculateMTGPKernelMatrix2(traindata,distMatrix,theta0,kernel_option);
    Km=diag(sigma0(train_task_index).^2)+original_Km;
    clear original_Km;
    if any(isinf(Km(:))+isnan(Km(:)))
        f=inf;
        g=ones(size(x))*inf;
        return;
    end
    L = chol(Km)';
    clear Km;
    inv_Km=L'\(L\eye(n));
    z=TransformFun(trainlabel,par0);
    f=z*inv_Km*z'/2+sum(log(diag(L)))-sum(LogDerivateofTransformFun(trainlabel,par0))+m*log(rho0)+sum(log(sigma0))+(log(sigma0)-mu0)*(log(sigma0)-mu0)'/(2*rho0^2);
    clear L;
    g=zeros(size(x));
    tmp=inv_Km*z';
    g((kernel_parameter_dim+1):kernel_parameter_dim+transform_parameter_dim)=[par0(1:3),1]'.*ParDerivateofTransformFun(trainlabel,tmp,par0);
    tmp=inv_Km-tmp*tmp';
    clear Km inv_Km;
    g(1:kernel_parameter_dim)=diag(theta0)*Tr(tmp,traindata,distMatrix,theta0)/2;
    g(kernel_parameter_dim+transform_parameter_dim+1)=(m*mu0-sum(log(sigma0)))/rho0^2;
    g(end)=m-(log(sigma0)-mu0)*(log(sigma0)-mu0)'/rho0^2;
    clear tmp z;
    clear traindata trainlabel train_task_index distMatrix insIndex;
    
function z=TransformFun(trainlabel,par)
    z=par(1)*log(par(2)*trainlabel+par(3))+par(4);
    clear trainlabel par;
    
function result=InvTransformFun(a,par)
    result=(exp((a-par(4))/par(1))-par(3))/par(2);
    clear a par;
    
function result=LogDerivateofTransformFun(trainlabel,par)
    result=log(par(1))+log(par(2))-log(par(2)*trainlabel+par(3));
    clear trainlabel par;
    
function result=ParDerivateofTransformFun(trainlabel,z,par)
    n=length(trainlabel);
    result=zeros(length(par),1);
    result(1)=log(par(2)*trainlabel+par(3))*z-n/par(1);
    result(2)=(par(1)*trainlabel./(par(2)*trainlabel+par(3)))*z-n/par(2)+sum(trainlabel./(par(2)*trainlabel+par(3)));
    result(3)=(par(1)./(par(2)*trainlabel+par(3)))*z+sum(1./(par(2)*trainlabel+par(3)));
    result(4)=sum(z);
    clear z trainlabel par;
    
function result=Tr(A,data,distMatrix,theta)
    derivation=KernelMatrixDerivation(data,distMatrix,theta);
    result=zeros(size(derivation,3),1);
    for i=1:length(result)
        result(i)=trace(A*derivation(:,:,i));
    end
    clear derivation A distMatrix data theta;
    
function derivation=KernelMatrixDerivation(data,disMatrix,theta)
    n=size(data,1);
    para_no=length(theta);
    derivation=zeros(n,n,para_no);
    derivation(:,:,1)=exp(-disMatrix/(2*theta(2)^2));
    derivation(:,:,2)=theta(1)*theta(2)^(-3)*(derivation(:,:,1).*disMatrix);
    clear disMatrix data theta;