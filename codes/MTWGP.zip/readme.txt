This package is to implement the MTWGP method in "Multi-Task Warped Gaussian Process for Personalized Age Estimation".

Please refer to the notes in MTWGP.m for the use.