function result=CalculateMTGPKernelMatrix(data1,data2,theta,option,varargin)
    m=size(data1,1);
    n=size(data2,1);
    result=zeros(m,n);
    if option==0
        result=theta(1)*data1*data2';
        theta=theta(2:end);
    elseif option==2
        num_comp=length(theta)/2;
    elseif option==3
        result=theta(3)*((data1*data2'+theta(4)).^varargin{1});
        theta=theta(1:2);
    elseif option==4
        result=theta(1)*((data1*data2'+theta(2)).^varargin{1});
        clear data1 data2 theta;
        return;
    elseif option==5
        result=theta*(data1*data2');
        clear data1 data2 theta;
        return;
    end
    for i=1:m
        for j=1:n
            if option==2
                dist=data1(i,:)-data2(j,:);
                dist=dist*dist';
                for k=1:num_comp
                    result(i,j)=result(i,j)+MTGP_kernelfunction(dist,dist,theta([2*k-1,2*k]),option);
                end
            else
                result(i,j)=result(i,j)+MTGP_kernelfunction(data1(i,:),data2(j,:),theta,option);
            end
        end
    end
    clear data1 data2 theta;
    
function result=MTGP_kernelfunction(x1,x2,theta,option)
    if option==0||option==1||option==3
        result=theta(1)*exp(-(x1-x2)*(x1-x2)'/(2*theta(2)^2));
    elseif option==2
        result=theta(1)*exp(-x1/(2*theta(2)^2));
    end
    clear x1 x2 theta;