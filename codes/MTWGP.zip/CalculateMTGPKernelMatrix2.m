function result=CalculateMTGPKernelMatrix2(data,distMatrix,theta,option,varargin)
    if option==0
        result=theta(1)*(data*data')+theta(2)*exp(-distMatrix/(2*theta(3)^2));
    elseif option==1
        result=theta(1)*exp(-distMatrix/(2*theta(2)^2));
    elseif option==2
        num_comp=length(theta)/2;
        result=zeros(size(distMatrix));
        for i=1:num_comp
            result=result+theta(2*i-1)*exp(-distMatrix/(2*theta(2*i)^2));
        end
    elseif option==3
        result=theta(1)*exp(-distMatrix/(2*theta(2)^2))+theta(3)*((data*data'+theta(4)).^varargin{1});
    elseif option==4
        result=theta(1)*((data*data'+theta(2)).^varargin{1});
    elseif option==5
        result=theta*(data*data');
    else
        error('The kernel option has not been specified');
    end
    clear data distMatrix theta;