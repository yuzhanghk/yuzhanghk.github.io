%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Copyright (C) 2015 Lei Han and Yu Zhang
% If you use this package, please cite the following paper:
% Lei Han and Yu Zhang. Learning Multi-Level Task Groups in Multi-Task Learning.
% In: Proceedings of the Twenty-Ninth AAAI Conference on Artificial Intelligence (AAAI), Austin Texas, USA, 2015.
% For any problem, please contact with Lei Han via email: leihan@comp.hkbu.edu.hk
% Last modified on Apr. 2015.
%% Description 
%  An example of the MeTaG model on microarray data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Load Data
clc;
clear all;
addpath(genpath(pwd));
load('Split_Data_Microarray_Ratio=0.6.mat');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Repeat_Num=length(Random_Split);
Repeat_X_Train=cell([1 Repeat_Num]);
Repeat_Y_Train=cell([1 Repeat_Num]);
Repeat_X_Validation=cell([1 Repeat_Num]);
Repeat_Y_Validation=cell([1 Repeat_Num]);
Repeat_X_Test=cell([1 Repeat_Num]);
Repeat_Y_Test=cell([1 Repeat_Num]);
for i=1:Repeat_Num
    Repeat_X_Train{i}=DX(Random_Split{i}.Train,:);
    Repeat_Y_Train{i}=DY(Random_Split{i}.Train,:);
    Repeat_X_Validation{i}=DX(Random_Split{i}.Validation,:);
    Repeat_Y_Validation{i}=DY(Random_Split{i}.Validation,:);
    Repeat_X_Test{i}=DX(Random_Split{i}.Test,:);
    Repeat_Y_Test{i}=DY(Random_Split{i}.Test,:);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
MeTaG_Lambda1=zeros([1 Repeat_Num]);
MeTaG_Beta=cell([1 Repeat_Num]);
MeTaG_Beta_H=cell([1 Repeat_Num]);
MeTaG_Result=cell([1 Repeat_Num]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=1:Repeat_Num
    clc;
    fprintf('Random Split Repetition: %d\n', i);
    %% MeTaG
    Lambda1_Vec=[0.1,1,10];
    H = 2;
    [MeTaG_Beta{i},MeTaG_Lambda1(i),MeTaG_Beta_H{i}]= ...
    Main_CV(Repeat_X_Train{i},Repeat_Y_Train{i},Repeat_X_Validation{i},Repeat_Y_Validation{i},'MeTaG',Lambda1_Vec,H);
    MeTaG_Result{i}=Main_Test(MeTaG_Beta{i},Repeat_X_Test{i},Repeat_Y_Test{i});
end
MeTaG_R=Calculate_Ave_Result(MeTaG_Result);
display(MeTaG_R);








