function Result=Main_Test(Beta,X_Test,Y_Test)
    [n,T]=size(Y_Test);
    temp_mse=zeros([1 T]);
    for t=1:T
        temp_mse(t)=norm(Y_Test(:,t)-X_Test*Beta(:,t),2)^2/n;
    end
    Result.MSE=mean(temp_mse);
end

