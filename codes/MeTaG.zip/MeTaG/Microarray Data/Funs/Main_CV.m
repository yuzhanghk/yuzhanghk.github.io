function [Best_W,lambda1,Best_W_H]=Main_CV(X_Train,Y_Train,X_Validation,Y_Validation,Method,...
    Lambda1_Vec,H)
[n,T]=size(Y_Train);
switch Method
    case 'MeTaG'
        MSE=zeros([1 length(Lambda1_Vec)]);
        W=cell([1 length(Lambda1_Vec)]);
        W_Hierarchy=cell([1 length(Lambda1_Vec)]);
        for i=1:length(Lambda1_Vec)
            [W{i},W_Hierarchy{i}]=MeTaG(X_Train,Y_Train,Lambda1_Vec(i),H);
            temp_mse=zeros([1 T]);
            for t=1:T
                temp_mse(t)=norm(Y_Validation(:,t)-X_Validation*W{i}(:,t),2)^2/n;
            end
            MSE(i)=mean(temp_mse);
        end
        [~,I]=min(MSE);
        lambda1=Lambda1_Vec(I);
        Best_W=W{I};
        Best_W_H=W_Hierarchy{I};
        return;
    otherwise
        display('Unkown method!');
end




