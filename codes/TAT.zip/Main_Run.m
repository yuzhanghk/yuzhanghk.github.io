%% Copyright (C) 2015 Lei Han and Yu Zhang
% If you use or modify this package, please cite the paper:
% Lei Han and Yu Zhang. Learning Tree Structure in Multi-Task Learning. KDD, 2015.
% You are welcome to improve this software.
% Please feel free to contact Lei Han via leihan.cs@gmail.com if you have any problem.
%% Description 
%  The main run
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
clc; clear;
addpath('./Data');
addpath('./Funcs');
load('Data.mat');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Repeat_Num = 10;
TAT_Lambda = zeros([1 Repeat_Num]);
TAT_W = cell([1 Repeat_Num]);
TAT_W_H = cell([1 Repeat_Num]);
TAT_Result = cell([1 Repeat_Num]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i = 1:Repeat_Num
    %% Train, cross-validation
    Lambda_Vec = 1e-5; %[1e-8,1e-7,1e-6,1e-5,1e-4,1e-3];
    Phi = 10;
    H = 6;
    fprintf('TAT: training, cross-validation and testing for repetition %d...\n', i);
    [TAT_W{i}, TAT_W_H{i}, TAT_Lambda(i)] = Main_CV(Repeat_X_Train{i}, Repeat_Y_Train{i}, ...
    Repeat_X_Validation{i}, Repeat_Y_Validation{i}, Lambda_Vec, Phi, W_True, H);
    %% Test
    TAT_Result{i} = Main_Test(TAT_W{i}, Repeat_X_Test{i}, Repeat_Y_Test{i}, W_True);
end
clc;
TAT_R = Calculate_Ave_Result(TAT_Result);
display(TAT_R);



