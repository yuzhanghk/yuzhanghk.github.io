%% Copyright (C) 2015 Lei Han and Yu Zhang
% If you use or modify this package, please cite the paper:
% Lei Han and Yu Zhang. Learning Tree Structure in Multi-Task Learning. KDD, 2015.
% You are welcome to improve this software.
% Please feel free to contact Lei Han via leihan.cs@gmail.com if you have
% any problem.

An example code for the TAT method. This example uses the synthetic data in Table 2 when H^* = 6 in the paper.