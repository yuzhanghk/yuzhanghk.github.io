%% Copyright (C) 2015 Lei Han and Yu Zhang
% If you use or modify this package, please cite the paper:
% Lei Han and Yu Zhang. Learning Tree Structure in Multi-Task Learning. KDD, 2015.
% You are welcome to improve this software.
% Please feel free to contact Lei Han via leihan.cs@gmail.com if you have any problem.
%% Description 
%  Algorithm 3 in the paper.
%%
function x = Algorithm3(b)
%% return a non-increasing sequence
n = length(b);
non_increasing_interval = cell([1 1]);
t = 0;
begin_idx = 1;
for i = 2:n
    if b(i) >= b(i-1)
        if i~=n
            continue;
        else
            end_idx = i;
            t = t + 1;
            non_increasing_interval{t}.sequence = b(begin_idx:end_idx);
            non_increasing_interval{t}.optimal = mean(non_increasing_interval{t}.sequence);
            non_increasing_interval{t}.size = length(non_increasing_interval{t}.sequence);
        end        
    else
        end_idx = i-1;
        t = t + 1;
        non_increasing_interval{t}.sequence = b(begin_idx:end_idx);
        non_increasing_interval{t}.optimal = mean(non_increasing_interval{t}.sequence);
        non_increasing_interval{t}.size = length(non_increasing_interval{t}.sequence);
        begin_idx = i;
        if i == n
            end_idx = i;
            t = t + 1;
            non_increasing_interval{t}.sequence = b(begin_idx:end_idx);
            non_increasing_interval{t}.optimal = mean(non_increasing_interval{t}.sequence);
            non_increasing_interval{t}.size = length(non_increasing_interval{t}.sequence);
        end
    end
end
L = t;
Stack = cell([1 L]);
t = 1;
Stack{t} = non_increasing_interval{1};
for i = 2:L
    if Stack{t}.optimal >= non_increasing_interval{i}.optimal
        t = t+1;
        Stack{t} = non_increasing_interval{i};
        continue;
    else
        Stack{t} = Combine(Stack{t}, non_increasing_interval{i});
        while 1
            %% check the top-2
            if t == 1
                break;
            else
                if Stack{t-1}.optimal < Stack{t}.optimal
                    Stack{t-1} = Combine(Stack{t-1}, Stack{t});
                    t = t-1;
                    continue;
                else
                    break;
                end
            end
        end
    end
end
%%
x = zeros([1 n]);
k = 1;
for i = 1:t
    for j = 1:Stack{i}.size
        x(k) = Stack{i}.optimal;
        k = k+1;
    end
end

end

function res = Combine(Seq_a,Seq_b)
new_optimal = (Seq_a.optimal*Seq_a.size + Seq_b.optimal*Seq_b.size)/(Seq_a.size + Seq_b.size);
res.optimal = new_optimal;
res.sequence = [Seq_a.sequence, Seq_b.sequence];
res.size = Seq_a.size + Seq_b.size;
end







