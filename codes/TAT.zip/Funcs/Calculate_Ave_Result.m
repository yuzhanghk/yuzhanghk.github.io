function R=Calculate_Ave_Result(Result)
N=length(Result);
MSE=zeros([1 N]);
for i=1:N
    MSE(i)=Result{i}.MSE;
end
R.MMSE=mean(MSE);
R.StdMSE=std(MSE);
