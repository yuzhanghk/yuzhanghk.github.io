%% Copyright (C) 2015 Lei Han and Yu Zhang
% If you use or modify this package, please cite the paper:
% Lei Han and Yu Zhang. Learning Tree Structure in Multi-Task Learning. KDD, 2015.
% You are welcome to improve this software.
% Please feel free to contact Lei Han via leihan.cs@gmail.com if you have any problem.
%% Description 
%  The TAT algorithm
%  Input:
%  X: multi task X in cell format
%  Y: multi task Y
%  Lamb and Phi: regularization parameters
%  H: number of layers of the tree
%  Output:
%  W: the model parameter
%  W_Hierarchy: the component parameter in each layer
%%
function [W, W_Hierarchy] = TAT_mtl(X, Y, Lamb, Phi, H)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
m = length(Y);
[n,d] = size(X{1});
%% Different parameters can be tried for different data
eps = 1e-3;
Sigma = 1e-5;
eta = 2;
tau_k = 1;
L_min = 1e-20;
L_max = 1e20;
Max_GISTIter = 500;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
lambda = zeros([1 H]);
lambda(1) = Lamb;
if H >= 2
    for h = 2:H
        lambda(h)=lambda(h-1)*Phi;
    end
else
    error('H should be larger than 1!');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
W_Hierarchy = cell([1 H]);
V_Hierarchy = cell([1 H]);
%% Initialize W
for h = 1:H
    W_Hierarchy{h} = zeros([d m]);
end
old_X_rec_full = zeros([d m]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% C is used to obtain the fusion regularizer
C = zeros([m*(m-1)/2 m]);
C_row_num = 1;
for i=1:m
    for j=i+1:m
        C(C_row_num,i) = 1;
        C(C_row_num,j) = -1;
        C_row_num = C_row_num+1;
    end
end
C = sparse(C);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% The GIST framework
for APG_iter = 1:Max_GISTIter
    %% find a small tau_k, initial tau_k \in [tau_min, tau_max]
    tau_k = min(max(tau_k, L_min), L_max); 
    while true
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        W_old = zeros([d m]);
        W_H_old = cell([1 H]);
        for h = 1:H
            W_old = W_old + W_Hierarchy{h};
            W_H_old{h} = W_Hierarchy{h};
        end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        L_Gradient = zeros([d m]);
        for col = 1:m
            L_Gradient(:,col) = 2/(m*n)*X{col}'*(X{col}*W_old(:,col)-Y{col});
        end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        for h = 1:H
            V_Hierarchy{h} = W_Hierarchy{h}-1/tau_k*L_Gradient;
        end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %% Solve proximal operator
        W_Hierarchy = sub_ADMM_TAT_mtl(W_Hierarchy,V_Hierarchy,tau_k,C,lambda);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %% line search
        W_rec_full = zeros(d,m);
        for h = 1:H
            W_rec_full = W_rec_full + W_Hierarchy{h};
        end
        if find_tau_k(X, Y, W_old, W_H_old, W_rec_full, W_Hierarchy, lambda, tau_k, Sigma, C) == 1
            break;
        else
            fprintf('Searching L_k (%f)...\n',tau_k);
            tau_k = tau_k * eta;
        end
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% check termination
    out_iter_error = norm(W_rec_full - old_X_rec_full, 'fro')/norm(old_X_rec_full,'fro');
    if(APG_iter>=2 && out_iter_error<eps)
        fprintf('break at out_iter = %1d\n',APG_iter);
        break;
    end
    fprintf('GISTA_iter = %1d, error = %f\n', APG_iter, out_iter_error);
    old_X_rec_full = W_rec_full;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
W = W_rec_full;
clc;

end



function isfind = find_tau_k(X, Y, W_k, W_H_k, W_kp1, W_H_kp1, lambda, tau_k, Sigma, C)
H = length(W_H_k);
[~, m] = size(W_H_k{1});
[n, ~] = size(X{1});
Q = cell([1 H]);
for h = 1:H
    Q{h}=C*W_H_k{h}';
end
Sum_Q12 = zeros([1 H]);
for h = 1:H
    for i = 1:m*(m-1)/2
        Sum_Q12(h) = Sum_Q12(h) + norm(Q{h}(i,:),2);
    end
    Sum_Q12(h) = Sum_Q12(h)*lambda(h);
end
temp = 0;
for col = 1:m
    temp = temp + norm(Y{col}-X{col}*W_k(:,col),2)^2;
end
fun_val_k = 1/(m*n)*temp+sum(Sum_Q12);
%%
for h = 1:H
    Q{h}=C*W_H_kp1{h}';
end
Sum_Q12 = zeros([1 H]);
for h = 1:H
    for i = 1:1:m*(m-1)/2
        Sum_Q12(h) = Sum_Q12(h) + norm(Q{h}(i,:),2);
    end
    Sum_Q12(h) = Sum_Q12(h)*lambda(h);
end
temp = 0;
for col = 1:m
    temp = temp + norm(Y{col}-X{col}*W_kp1(:,col),2)^2;
end
fun_val_kp1 = 1/(m*n)*temp+sum(Sum_Q12);
%%
if fun_val_kp1 <= fun_val_k - Sigma*tau_k/2*norm(W_kp1-W_k,'fro')^2
    isfind = 1;
else
    isfind = 0;
end



end