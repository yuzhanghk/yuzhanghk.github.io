function Result=Main_Test(W, X_Test, Y_Test, W_True)
    T = length(X_Test);
    [n,~] = size(X_Test{1});
    temp_mse = zeros([1 T]);
    for t = 1:T
        temp_mse(t) = (W(:,t) - W_True(:,t))'*(X_Test{t}'*X_Test{t})*(W(:,t) - W_True(:,t))/n;
    end
    Result.MSE = mean(temp_mse);
end



