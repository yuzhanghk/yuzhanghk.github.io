%% Copyright (C) 2015 Lei Han and Yu Zhang
% If you use or modify this package, please cite the paper:
% Lei Han and Yu Zhang. Learning Tree Structure in Multi-Task Learning. KDD, 2015.
% You are welcome to improve this software.
% Please feel free to contact Lei Han via leihan.cs@gmail.com if you have any problem.
%% Description 
%  Solve Q
%%
function Q_Hierarchy = SolveQ(U_Hierarchy)
addpath('./Sequence');
H = length(U_Hierarchy);
[m, n] = size(U_Hierarchy{1});
U_reshape = zeros(m*n, H);
for h = 1:H
    U_reshape(:, h) = reshape(U_Hierarchy{h}, [m*n 1]);
end
Sign_U = sign(U_reshape);
U_reshape = abs(U_reshape);
%%
% In the following, m*n implementations of algorithm3 need to be ran.
% Here, the simplest sequential implementation is provided as a tutorial. 
% Note that Maltab implementation of large loops could be very slow,
% but many ways can be used to improve the efficiency, e.g., 
% parallelization, modifying Algorithm3 into matrix version, or realizing 
% 'SolveQ' function by C, C++.
for i = 1:m*n
    U_reshape(i, :) = Algorithm3(U_reshape(i, :));
end
%%
U_reshape = Sign_U.*U_reshape;
Q_Hierarchy = cell(1, H);
for h = 1:H
    Q_Hierarchy{h} = reshape(U_reshape(:, h), [m n]);
end


end