%% Copyright (C) 2015 Lei Han and Yu Zhang
% If you use or modify this package, please cite the paper:
% Lei Han and Yu Zhang. Learning Tree Structure in Multi-Task Learning. KDD, 2015.
% You are welcome to improve this software.
% Please feel free to contact Lei Han via leihan.cs@gmail.com if you have any problem.
%% Description 
%  The ADMM algorithm
%%
function W_H_pre =sub_ADMM_TAT_mtl(W_Hierarchy, V_Hierarchy, tau_k, C, Lamb)
MAXiter_num = 200;
eps = 1e-2;
Rho = 1;
H = length(W_Hierarchy);
[d, m] = size(W_Hierarchy{1});
P_Hierarchy = cell([1 H]);
Th_Hierarchy = cell([1 H]);
Q_Hierarchy = cell([1 H]);
Ga_Hierarchy = cell([1 H]);
S_Hierarchy = cell([1 H]);
U_Hierarchy = cell([1 H]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
CC = C'*C;
CW = cell([1 H]);
inv_ICC = inv(tau_k*eye(m)+Rho*CC);
for h=1:H
    P_Hierarchy{h} = zeros([m*(m-1)/2 d]);
    Th_Hierarchy{h} = zeros([m*(m-1)/2 d]);
    Q_Hierarchy{h} = C*W_Hierarchy{h}';
    Ga_Hierarchy{h} = zeros([m*(m-1)/2 d]);
    S_Hierarchy{h} = zeros([m*(m-1)/2 d]);
    U_Hierarchy{h} = zeros([m*(m-1)/2 d]);
end
old_X_rec_full = zeros(d,m);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for iter = 1:MAXiter_num
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% Solve W
    for h = 1:H
        A = (tau_k*V_Hierarchy{h}+(Rho*Q_Hierarchy{h}'+Ga_Hierarchy{h}')*C);
        B = inv_ICC;
        W_Hierarchy{h} = A*B;            
    end
    %% Solve P
    for h = 1:H
        S_Hierarchy{h} = Q_Hierarchy{h}-1/Rho*Th_Hierarchy{h};
        for i = 1:m*(m-1)/2
            P_Hierarchy{h}(i,:) = max(0, 1-Lamb(h)/norm(S_Hierarchy{h}(i,:),2))*S_Hierarchy{h}(i,:);
        end
    end
    %% Solve Q
    for h = 1:H
        CW{h} = C*W_Hierarchy{h}';
        U_Hierarchy{h} = 0.5 * ( P_Hierarchy{h}+CW{h}-1/Rho*Ga_Hierarchy{h}+1/Rho*Th_Hierarchy{h} );
    end
    %% Quick check of intolerant violate (a simple trick to speedup)
    Tag = 0;
    for h = 1:H-1
        diff_U = abs(U_Hierarchy{h}) - abs(U_Hierarchy{h+1});
        min_U = min(min(diff_U)); % min_U < 0 means violate happens
        max_U = max(max(abs(U_Hierarchy{h})));
        if min_U / max_U < - 0.06 % pre-defined tolerance
            Tag = 1;
            break;
        end
    end
    if Tag == 1
        fprintf('Intolerant violate of the sequential constraint exists. Solving Q...\n');
        Q_Hierarchy = SolveQ(U_Hierarchy);
    else
        Q_Hierarchy = U_Hierarchy;
    end
    %% Update Ga and Th
    for h = 1:H
        Th_Hierarchy{h} = Th_Hierarchy{h} + Rho*(P_Hierarchy{h}-Q_Hierarchy{h});
        Ga_Hierarchy{h} = Ga_Hierarchy{h} + Rho*(Q_Hierarchy{h}-CW{h});
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% check termination
    X_rec_full = zeros(d,m);
    for h = 1:H
        X_rec_full = X_rec_full + W_Hierarchy{h};
    end
    out_iter_error = norm(X_rec_full-old_X_rec_full,'fro')/norm(old_X_rec_full,'fro');
    if(iter >= 2 && out_iter_error < eps)
        break;
    end
    old_X_rec_full = X_rec_full;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
W_H_pre = W_Hierarchy;

end



