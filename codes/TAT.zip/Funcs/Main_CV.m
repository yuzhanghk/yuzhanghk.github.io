function [Best_W, Best_W_H, Lambda] = Main_CV(X_Train, Y_Train, ...
    X_Validation, Y_Validation, Lambda_Vec, Phi, W_True, H)
T = length(Y_Train);
n = size(X_Train,1);
MSE = zeros([1 length(Lambda_Vec)]);
W = cell([1 length(Lambda_Vec)]);
W_H = cell([1 length(Lambda_Vec)]);
for i=1:length(Lambda_Vec)
    [W{i}, W_H{i}] = TAT_mtl(X_Train, Y_Train, Lambda_Vec(i), Phi, H);
    temp_mse = zeros([1 T]);
    for t = 1:T
        temp_mse(t) = (W{i}(:,t)-W_True(:,t))'*(X_Validation{t}'*X_Validation{t})*(W{i}(:,t)-W_True(:,t))/n;
    end
    MSE(i)=mean(temp_mse);
end
[~,Ii] = min(MSE);
Lambda = Lambda_Vec(Ii);
Best_W = W{Ii};
Best_W_H = W_H{Ii};

end




