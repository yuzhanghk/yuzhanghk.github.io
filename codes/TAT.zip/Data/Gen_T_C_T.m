%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;
clear;
load('W_True.mat');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
n=100;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sigma_noise=1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Repeat_Num=10;
Repeat_X_Train=cell([1 Repeat_Num]);
Repeat_Y_Train=cell([1 Repeat_Num]);
Repeat_X_Validation=cell([1 Repeat_Num]);
Repeat_Y_Validation=cell([1 Repeat_Num]);
Repeat_X_Test=cell([1 Repeat_Num]);
Repeat_Y_Test=cell([1 Repeat_Num]);
for i=1:Repeat_Num
    [Repeat_X_Train{i},Repeat_Y_Train{i}]=Gen_Data(m,d,n,W_True,sigma_noise);
    [Repeat_X_Validation{i},Repeat_Y_Validation{i}]=Gen_Data(m,d,n,W_True,sigma_noise);
    [Repeat_X_Test{i},Repeat_Y_Test{i}]=Gen_Data(m,d,n,W_True,sigma_noise);
end
save('Data.mat','Repeat_X_Train','Repeat_Y_Train',...
'Repeat_X_Validation','Repeat_Y_Validation','Repeat_X_Test','Repeat_Y_Test','W_True','Repeat_Num');





