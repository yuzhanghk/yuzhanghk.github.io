function [X,Y]=Gen_Data(m,d,n,W,sigma_noise)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
X=cell([1 m]);
Y=cell([1 m]);
for i=1:m
    for j=1:d
        X{i}(:,j)=normrnd(0,1,[n 1]);
    end
end
for i=1:m
    Y{i}=X{i}*W(:,i)+normrnd(0,sigma_noise,[n 1]);
end





