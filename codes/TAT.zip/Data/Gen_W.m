%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;
clear;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
m=32;
d=100;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Gen W
H = 6;
W_H = cell([1 H]);
W_H{1} = zeros([d m]);
%%
Sigma = 1;
W_H{1}(:,1) = mvnrnd(ones([d 1]),Sigma);
for i = 2:m
    W_H{1}(:,i) = W_H{1}(:,1);
end
%%
W_H{2} = zeros([d m]);
Sigma = 0.2;
for i=1:2
    W_H{2}(:,(i-1)*m/2+1:i*m/2) = repmat( W_H{1}(:,1) + abs( mvnrnd(zeros([d 1]),Sigma) ), [1 m/2] );
end
%%
W_H{3} = zeros([d m]);
Sigma = 0.2;
for i=1:4
    j = fix((i-1)/2)+1;
    W_H{3}(:,(i-1)*m/4+1:i*m/4) = repmat( W_H{2}(:,(j-1)*m/2+1) + abs( mvnrnd(zeros([d 1]),Sigma) ), [1 m/4] );
end
%%
W_H{4} = zeros([d m]);
Sigma = 0.2;
for i=1:8
    j = fix((i-1)/2)+1;
    W_H{4}(:,(i-1)*m/8+1:i*m/8) = repmat( W_H{3}(:,(j-1)*m/4+1) + abs( mvnrnd(zeros([d 1]),Sigma) ), [1 m/8]);
end
%%
W_H{5} = zeros([d m]);
Sigma = 0.2;
for i=1:16
    j = fix((i-1)/2)+1;
    W_H{5}(:,(i-1)*m/16+1:i*m/16) = repmat( W_H{4}(:,(j-1)*m/8+1) + abs( mvnrnd(zeros([d 1]),Sigma) ), [1 m/16]);
end
%%
W_H{6} = zeros([d m]);
Sigma = 0.5;
for i=1:32
    j = fix((i-1)/2)+1;
    W_H{6}(:,(i-1)*m/32+1:i*m/32) = repmat( W_H{5}(:,(j-1)*m/16+1) + abs( mvnrnd(zeros([d 1]),Sigma) ), [1 m/32]);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Draw W
W = zeros([d m]);
for i = 1:H
    figure, imshow(W_H{i}/max(max(abs(W_H{i}))));
    W = W + W_H{i};
end
W_True = W;
W_True = W_True/max(max(abs(W_True)));
figure,imshow(W_True/max(max(abs(W_True))));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
save('W_True.mat','W_True','W_H','m','d');


