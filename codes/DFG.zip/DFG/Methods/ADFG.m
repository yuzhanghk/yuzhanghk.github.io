function Beta = ADFG(X,Y,lambda1,lambda2,lambda3,Gamma)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Copyright (C) 2015 Lei Han and Yu Zhang
% If you use this package, please cite the following paper:
% Lei Han and Yu Zhang. Discriminative Feature Grouping.
% In: Proceedings of the Twenty-Ninth AAAI Conference on Artificial Intelligence (AAAI), Austin Texas, USA, 2015.
%
% For any problem, please contact with Lei Han via email: leihan@comp.hkbu.edu.hk
% Last modified on Feb. 2015.
%% Description 
%  The main code for the ADFG model
%% Input parameters:
%  X - Data Matrix
%  Y - Responses
%  lambda1 - Regularization parameter before the l1 term.
%  lambda2 - Regularization parameter before the adaptive grouping term.
%  lambda3 - Regularization parameter before the adaptive discriminating term.
%  Gamma - The hyper-parameter.
%% Output parameters:
%  Beta - Solution
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
p=size(X,2);
Max_Iter_Num=200;
rho=1;
trolorence=1e-4;
%%
mu=zeros([p 1]);
v=zeros([p*(p-1)*(p-2)/2 1]);
u=zeros([p*(p-1)/2 1]);
P=zeros([p*(p-1)*(p-2)/2 1]);
Q=zeros([p 1]);
R=zeros([p*(p-1)/2 1]);
T2=zeros([p*(p-1)/2 p]);
T2_t=1;
T3=zeros([p*(p-1)*(p-2)/2 p]);
T3_t=1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
w=zeros([p p]);
for i=1:p
    for j=1:p
        Co=corrcoef(X(:,i),X(:,j));
        w(i,j)=Co(1,2);
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
MLEst_beta=lscov(X,Y); % the least square estimator
rho_corre=zeros([p p]);
for i=1:p
    for j=1:p
        if i==j
            rho_corre(i,j)=Inf;
            continue;
        end
        if MLEst_beta(i)~=MLEst_beta(j)
            rho_corre(i,j)=(abs(MLEst_beta(i)-MLEst_beta(j)))^(-Gamma);
        else
            rho_corre(i,j)=Inf;
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=1:p
    for j=i+1:p
        T2(T2_t, i) = rho_corre(i,j);
        T2(T2_t, j) = -rho_corre(i,j);
        T2_t = T2_t+1;
    end
end

for i=1:p
    for j=1:p
        for k=j+1:p
            if j == i || k == i
               continue;
            end
            T3(T3_t, i) = rho_corre(i,j)+rho_corre(i,k);
            T3(T3_t, j) = -rho_corre(i,j);
            T3(T3_t, k) = -rho_corre(i,k);
            T3_t = T3_t+1;
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
mu_k=mu;
v_k=v;
u_k=u;
P_k=P;
Q_k=Q;
R_k=R;
F = X'*X+rho*(eye(p)+T3'*T3+T2'*T2);
beta_k=zeros([p 1]);
for iter=1:Max_Iter_Num
    clc;
    fprintf('Iter = %d \n',iter);
    old_beta=beta_k;
    b_k = X'*Y-mu_k-T3'*v_k-T2'*u_k+rho*T3'*P_k+rho*T2'*R_k+rho*Q_k;
    R = chol(F);
    beta_k=inv(R)*(inv(R')*b_k);
%%
    Q_temp=beta_k+1/rho*mu_k;
    Q_k=abs(Q_temp)-lambda1/rho;
    for i=1:p
        if Q_k(i) <0
            Q_k(i)=0;
        else
            Q_k(i)=sign(Q_temp(i))*Q_k(i);
        end
    end
%%
    P_temp=T3*beta_k+1/rho*v_k;
    P_k=abs(P_temp)-lambda2/rho;
    for i=1:p*(p-1)*(p-2)/2
        if P_k(i) <0
            P_k(i)=0;
        else
            P_k(i)=sign(P_temp(i))*P_k(i);
        end
    end
%%
    R_temp=T2*beta_k+1/rho*u_k;
    R_k=abs(R_temp)-lambda3/rho;
    for i=1:p*(p-1)/2
        if R_k(i) <0
            R_k(i)=0;
        else
            R_k(i)=sign(R_temp(i))*R_k(i);
        end
    end
%%
    mu_k=mu_k+rho*(beta_k-Q_k);
    v_k=v_k+rho*(T3*beta_k-P_k);
    u_k=u_k+rho*(T2*beta_k-R_k);
%%
    if norm(old_beta-beta_k,'fro')/norm(old_beta,'fro') < trolorence
        break;
    end
end
Beta = beta_k;

end

