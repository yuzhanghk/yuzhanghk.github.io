%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Copyright (C) 2015 Lei Han and Yu Zhang
% If you use this package, please cite the following paper:
% Lei Han and Yu Zhang. Discriminative Feature Grouping.
% In: Proceedings of the Twenty-Ninth AAAI Conference on Artificial Intelligence (AAAI), Austin Texas, USA, 2015.
%
% For any problem, please contact with Lei Han via email: leihan@comp.hkbu.edu.hk
% Last modified on Feb. 2015.
%% Description 
%  An example of the DFG model on synthetic data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;
clear all;
%% Load Data
addpath('.\Toy_Data');
addpath('.\Methods');
X=textread('X_train.txt');
Y=textread('Y_train.txt');
X_test=textread('X_test.txt');
Y_test=textread('Y_test.txt');
beta_truth=[repmat(3,1,10),repmat(2.8,1,10),repmat(2,1,10),zeros(1,10)]';
%% hyper-parameters (use the cross-validation method to select these parameters)
lambda1=10;
lambda2=0.01;
%%
[n,p]=size(X);
Beta = DFG(X,Y,lambda1,lambda2); % run DFG
[m1,n1]=size(X_test);
MSE_test=(Beta-beta_truth)'*(X_test'*X_test)*(Beta-beta_truth)/m1;
fprintf('Test MSE = %f\n',MSE_test);
%% plot
xx=(1:1:p);
yy=Beta';
set(gca,'FontName','Times New Roman','FontSize',20);
plot(xx,yy,'.','MarkerSize',16);
