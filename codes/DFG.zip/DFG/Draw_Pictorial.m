%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Copyright (C) 2015 Lei Han and Yu Zhang
% If you use this package, please cite the following paper:
% Lei Han and Yu Zhang. Discriminative Feature Grouping.
% In: Proceedings of the Twenty-Ninth AAAI Conference on Artificial Intelligence (AAAI), Austin Texas, USA, 2015.
%
% For any problem, please contact with Lei Han via email: leihan@comp.hkbu.edu.hk
% Last modified on Feb. 2015.
%% Description 
%  Draw the pictorial representations of the DFG & ADFG regularizers
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear;
clc;
%% The following function plots the Figure 2(d) in the paper
[x,y,z]=meshgrid(linspace(-10,10));
val=0.4*0.5*(abs(2*x-y-z)+abs(2*y-z-x)+abs(2*z-y-x))...
+0.2*0.5*(abs(abs(x)-abs(y))+abs(abs(y)-abs(z))+abs(abs(z)-abs(x)))...
+1*(abs(x)+abs(y)+abs(z));
isosurface(x,y,z,val,10)
axis equal